#!/bin/sh

# Name : Patel Devarshi Chandrakant
# Roll No : 18CS10040
# ASSIGNMENT 4 | Computer Networks Laboratory


#  PART A

# Creating namespaces
sudo ip netns add N1
sudo ip netns add N2
sudo ip netns add N3
sudo ip netns add N4

# Creating veths' and linking them with each other according to question
sudo ip link add v1 type veth peer name v2
sudo ip link add v3 type veth peer name v4
sudo ip link add v5 type veth peer name v6 

# Linking veths' with their respective namespaces
sudo ip link set v1 netns N1
sudo ip link set v2 netns N2
sudo ip link set v3 netns N2
sudo ip link set v4 netns N3
sudo ip link set v5 netns N3
sudo ip link set v6 netns N4

# IP Addressing of veth and setting them to 'up'
sudo ip -n N1 addr add 10.0.10.40/24 dev v1
sudo ip -n N1 link set dev v1 up
sudo ip -n N2 addr add 10.0.10.41/24 dev v2
sudo ip -n N2 link set dev v2 up
sudo ip -n N2 addr add 10.0.20.40/24 dev v3
sudo ip -n N2 link set dev v3 up
sudo ip -n N3 addr add 10.0.20.41/24 dev v4
sudo ip -n N3 link set dev v4 up
sudo ip -n N3 addr add 10.0.30.40/24 dev v5
sudo ip -n N3 link set dev v5 up
sudo ip -n N4 addr add 10.0.30.41/24 dev v6
sudo ip -n N4 link set dev v6 up

#Addying routes to route table
sudo ip -n N2 route add 10.0.30.0/24 via 10.0.20.41 dev v3 
sudo ip -n N4 route add 10.0.20.0/24 via 10.0.30.40 dev v6
sudo ip -n N3 route add 10.0.10.0/24 via 10.0.20.40 dev v4
sudo ip -n N1 route add 10.0.20.0/24 via 10.0.10.41 dev v1
sudo ip -n N1 route add 10.0.30.0/24 via 10.0.10.41 dev v1
sudo ip -n N4 route add 10.0.10.0/24 via 10.0.30.40 dev v6

#Enabling loop back to ping own interfaces by a namespace(sanity check)
sudo ip -n N1 link set lo up
sudo ip -n N2 link set lo up
sudo ip -n N3 link set lo up
sudo ip -n N4 link set lo up 

#IP forwarding on
sudo sysctl -w  net.ipv4.ip_forward=1

#Pinging all interfaces
sudo ip netns exec N1 ping -c3 10.0.10.40
sudo ip netns exec N1 ping -c3 10.0.10.41
sudo ip netns exec N1 ping -c3 10.0.20.40
sudo ip netns exec N1 ping -c3 10.0.20.41
sudo ip netns exec N1 ping -c3 10.0.30.40
sudo ip netns exec N1 ping -c3 10.0.30.41

sudo ip netns exec N2 ping -c3 10.0.10.40
sudo ip netns exec N2 ping -c3 10.0.10.41
sudo ip netns exec N2 ping -c3 10.0.20.40
sudo ip netns exec N2 ping -c3 10.0.20.41
sudo ip netns exec N2 ping -c3 10.0.30.40
sudo ip netns exec N2 ping -c3 10.0.30.41

sudo ip netns exec N3 ping -c3 10.0.10.40
sudo ip netns exec N3 ping -c3 10.0.10.41
sudo ip netns exec N3 ping -c3 10.0.20.40
sudo ip netns exec N3 ping -c3 10.0.30.40
sudo ip netns exec N3 ping -c3 10.0.20.41
sudo ip netns exec N3 ping -c3 10.0.30.41

sudo ip netns exec N4 ping -c3 10.0.10.40
sudo ip netns exec N4 ping -c3 10.0.10.41
sudo ip netns exec N4 ping -c3 10.0.20.40
sudo ip netns exec N4 ping -c3 10.0.20.41
sudo ip netns exec N4 ping -c3 10.0.30.40
sudo ip netns exec N4 ping -c3 10.0.30.41





