#!/bin/sh

# Name : Patel Devarshi Chandrakant
# Roll No : 18CS10040
# ASSIGNMENT 4 | Computer Networks Laboratory


#  PART B

# Creating namespaces
sudo ip netns add R1
sudo ip netns add R2
sudo ip netns add R3
sudo ip netns add H1
sudo ip netns add H2
sudo ip netns add H3
sudo ip netns add H4

# Creating veths' and linking them with each other according to question
sudo ip link add V1 type veth peer name V2
sudo ip link add V3 type veth peer name V4
sudo ip link add V5 type veth peer name V6 
sudo ip link add V7 type veth peer name V8
sudo ip link add V9 type veth peer name V10
sudo ip link add V11 type veth peer name V12 

# Linking veths' with their respective namespaces
sudo ip link set V1 netns H1
sudo ip link set V3 netns H2
sudo ip link set V10 netns H3
sudo ip link set V12 netns H4

sudo ip link set V2 netns R1
sudo ip link set V4 netns R1
sudo ip link set V5 netns R1

sudo ip link set V6 netns R2
sudo ip link set V7 netns R2

sudo ip link set V9 netns R3
sudo ip link set V8 netns R3
sudo ip link set V11 netns R3


# IP Addressing of veth and setting them to 'up'
sudo ip -n H1 addr add 10.0.10.40/24 dev V1
sudo ip -n H1 link set dev V1 up
sudo ip -n R1 addr add 10.0.10.41/24 dev V2
sudo ip -n R1 link set dev V2 up
sudo ip -n H2 addr add 10.0.20.40/24 dev V3
sudo ip -n H2 link set dev V3 up
sudo ip -n R1 addr add 10.0.20.41/24 dev V4
sudo ip -n R1 link set dev V4 up
sudo ip -n R1 addr add 10.0.30.40/24 dev V5
sudo ip -n R1 link set dev V5 up
sudo ip -n R2 addr add 10.0.30.41/24 dev V6
sudo ip -n R2 link set dev V6 up
sudo ip -n R2 addr add 10.0.40.40/24 dev V7
sudo ip -n R2 link set dev V7 up
sudo ip -n R3 addr add 10.0.40.41/24 dev V8
sudo ip -n R3 link set dev V8 up
sudo ip -n R3 addr add 10.0.50.40/24 dev V9
sudo ip -n R3 link set dev V9 up
sudo ip -n H3 addr add 10.0.50.41/24 dev V10
sudo ip -n H3 link set dev V10 up
sudo ip -n R3 addr add 10.0.60.40/24 dev V11
sudo ip -n R3 link set dev V11 up
sudo ip -n H4 addr add 10.0.60.41/24 dev V12
sudo ip -n H4 link set dev V12 up

#Addying routes to route table
sudo ip -n R1 route add 10.0.40.0/24 via 10.0.30.41 dev V5
sudo ip -n R1 route add 10.0.50.0/24 via 10.0.30.41 dev V5
sudo ip -n R1 route add 10.0.60.0/24 via 10.0.30.41 dev V5

sudo ip -n R2 route add 10.0.10.0/24 via 10.0.30.40 dev V6
sudo ip -n R2 route add 10.0.20.0/24 via 10.0.30.40 dev V6
sudo ip -n R2 route add 10.0.50.0/24 via 10.0.40.41 dev V7
sudo ip -n R2 route add 10.0.60.0/24 via 10.0.40.41 dev V7

sudo ip -n R3 route add 10.0.10.0/24 via 10.0.40.40 dev V8
sudo ip -n R3 route add 10.0.20.0/24 via 10.0.40.40 dev V8
sudo ip -n R3 route add 10.0.30.0/24 via 10.0.40.40 dev V8

sudo ip -n H1 route add 10.0.20.0/24 via 10.0.10.41 dev V1
sudo ip -n H1 route add 10.0.30.0/24 via 10.0.10.41 dev V1
sudo ip -n H1 route add 10.0.40.0/24 via 10.0.10.41 dev V1
sudo ip -n H1 route add 10.0.50.0/24 via 10.0.10.41 dev V1
sudo ip -n H1 route add 10.0.60.0/24 via 10.0.10.41 dev V1

sudo ip -n H2 route add 10.0.10.0/24 via 10.0.20.41 dev V3
sudo ip -n H2 route add 10.0.30.0/24 via 10.0.20.41 dev V3
sudo ip -n H2 route add 10.0.40.0/24 via 10.0.20.41 dev V3
sudo ip -n H2 route add 10.0.50.0/24 via 10.0.20.41 dev V3
sudo ip -n H2 route add 10.0.60.0/24 via 10.0.20.41 dev V3

sudo ip -n H3 route add 10.0.10.0/24 via 10.0.50.40 dev V10
sudo ip -n H3 route add 10.0.20.0/24 via 10.0.50.40 dev V10
sudo ip -n H3 route add 10.0.30.0/24 via 10.0.50.40 dev V10
sudo ip -n H3 route add 10.0.40.0/24 via 10.0.50.40 dev V10
sudo ip -n H3 route add 10.0.60.0/24 via 10.0.50.40 dev V10

sudo ip -n H4 route add 10.0.10.0/24 via 10.0.60.40 dev V12
sudo ip -n H4 route add 10.0.20.0/24 via 10.0.60.40 dev V12
sudo ip -n H4 route add 10.0.30.0/24 via 10.0.60.40 dev V12
sudo ip -n H4 route add 10.0.40.0/24 via 10.0.60.40 dev V12
sudo ip -n H4 route add 10.0.50.0/24 via 10.0.60.40 dev V12

#Enabling loop back to ping own interfaces by a namespace(sanity check)
sudo ip -n H1 link set lo up
sudo ip -n H2 link set lo up
sudo ip -n H3 link set lo up
sudo ip -n H4 link set lo up 
sudo ip -n R1 link set lo up
sudo ip -n R2 link set lo up
sudo ip -n R3 link set lo up

#IP forwarding on
sudo sysctl -w  net.ipv4.ip_forward=1

#Pinging each interface
x=1
while [ $x -le 6 ]
do
    	echo -e "\n"
	y=$((x*10))
	sudo ip netns exec H1 ping -c3 10.0."$y".40 
	sudo ip netns exec H2 ping -c3 10.0."$y".40 
	sudo ip netns exec H3 ping -c3 10.0."$y".40 
	sudo ip netns exec H4 ping -c3 10.0."$y".40 
	sudo ip netns exec R1 ping -c3 10.0."$y".40 
	sudo ip netns exec R2 ping -c3 10.0."$y".40 
	sudo ip netns exec R3 ping -c3 10.0."$y".40 
	sudo ip netns exec H1 ping -c3 10.0."$y".41 
	sudo ip netns exec H2 ping -c3 10.0."$y".41 
	sudo ip netns exec H3 ping -c3 10.0."$y".41 
	sudo ip netns exec H4 ping -c3 10.0."$y".41 
	sudo ip netns exec R1 ping -c3 10.0."$y".41 
	sudo ip netns exec R2 ping -c3 10.0."$y".41 
	sudo ip netns exec R3 ping -c3 10.0."$y".41 
	x=$((x+1))
done

#Traceroutes
echo -e "\nTraceroute from H1 to H4"
sudo ip netns exec H1 traceroute 10.0.60.41
echo -e "\nTraceroute from H3 to H4"
sudo ip netns exec H3 traceroute 10.0.60.41
echo -e "\nTraceroute from H4 to H2"
sudo ip netns exec H4 traceroute 10.0.20.40



